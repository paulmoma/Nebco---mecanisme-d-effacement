## 0. Décomposition du problème réel

L'activité d'un OE sur le mécanisme NEBCO se décompose en niveaux de
décision emboîtés :

```
Niveau 0  │ Caractérisation portefeuille (baseline, gisement)   ── hors scope
Niveau 1  │ Offre sur le marché NEBCO                           ── hors scope
Niveau 2  │ Dispatch interne post-notification RTE              ── CE PROJET
Niveau 3  │ Pilotage temps réel des équipements                 ── hors scope
```

Chaque niveau prend en entrée les sorties du niveau précédent et fournit les données du suivant. La chaîne boucle : le réalisé mesuré au Niveau 3 alimente en retour le Niveau 0 (mise à jour des baselines, de la fiabilité des clients, du gisement effectif), qui conditionne les offres du Niveau 1 du jour suivant. Un dispatch de mauvaise qualité dégrade l'indicateur de fiabilité de l'OE, ce qui resserre à son tour le plafond réglementaire (art. 5.E.1.3.2.2).

Le Niveau 2 hérite du Niveau 1 un programme retenu `E_t^{retenu}` et un revenu fixé. Il rend au Niveau 3 un plan d'activation `δ[c,t]` et un profil de puissance `x[c,t]` par client. Ses variables de décision n'affectent ni le revenu (fixé au Niveau 1) ni le versement fournisseur (proportionnel au volume global, pas à la répartition interne), ce qui permet de simplifier la fonction objectif (cf. section 2).



2. Dans la section "Périmètre modélisé" (section 1 actuelle)
# À ajouter après le paragraphe sur la non-distinction Télérelevée/Profilée :
La distinction Télérelevée/Profilée a des conséquences qui dépassent le
Niveau 2 et touchent directement le Niveau 1 (offre sur le marché). En
effet, le **barème de versement fournisseur** (art. L.271-3 et R.271-8 du
Code de l'énergie) est **différencié par typologie d'EDE** : il existe un
barème forfaitaire pour les sites télérelevés et des barèmes distincts pour
les sites profilés (eux-mêmes sous-différenciés par profil de consommation,
par exemple RES 1, PRO 1, etc.). Ce barème, publié annuellement par RTE, est différencié entre sites télérelevés (puissance > 36 kVA) et sites profilés (puissance ≤ 36 kVA), avec des formules propres à chaque catégorie.

En conséquence, lorsque l'OE construit son offre au Niveau 1, il doit
anticiper le versement fournisseur en fonction de la composition de ses EDE
— une EDE Profilée résidentielle n'a pas le même barème qu'une EDE
Télérelevée industrielle. Cette différenciation n'a aucun impact sur le
Niveau 2 (le versement est constant par rapport aux variables de dispatch,
cf. section 2), mais elle conditionne la marge nette que l'OE peut espérer,
et donc le prix auquel il peut offrir.


3. Dans la section "Fonction objectif" (section 2 actuelle)
# Un petit renvoi dans le paragraphe sur la condition 2 du barème B :
2. **Le barème `B` est indépendant du client *au sein d'une même EDE*.**
   En réalité, les barèmes sont différenciés par typologie d'EDE
   (Télérelevée vs Profilée) et par profil de consommation. Dans le modèle
   v1 qui ne considère qu'une seule EDE, `B` est bien uniforme et la
   simplification est correcte. Dans une extension multi-EDE, il faudrait
   un `B_e` par EDE, ce qui modifierait l'arbitrage de partition de la
   consigne entre EDE au Niveau 1, sans toutefois affecter le dispatch
   interne au Niveau 2 (chaque `B_e` restant constant par rapport aux
   variables de dispatch de son EDE).
