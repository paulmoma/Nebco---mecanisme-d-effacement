---
title: "Note technique — Choix de modélisation du dispatch NEBCO"
author: "Paul Molaro-Maqua"
date: "21/04/2026"
---

# Note technique — Choix de modélisation du dispatch NEBCO

Cette note rappelle succinctement le cadre réglementaire du mécanisme NEBCO et développe les choix de modélisation. Elle apporte également les justifications qui n'ont pas leur place dans le README ; elle le complète sans le dupliquer.

## Sommaire
1. [Cadre réglementaire du NEBCO et décomposition du problème](#1-cadre-réglementaire-du-NEBCO-et-décomposition-du-problème)
2. [Périmètre modélisé : un OE, une EDE, sans distinction de profilage](#2-périmètre-modélisé)
3. [Modélisation et fonction objectif](#3-modélisation-et-fonction-objectif)
4. [Pourquoi MILP plutôt que LP](#4-pourquoi-milp-plutôt-que-lp)
5. [Modélisation du rebond : Position A vs matrice impulsionnelle](#5-modélisation-du-rebond)
6. [Bilan énergétique C3 : horizon local vs période glissante NEBCO](#6-bilan-énergétique-c3)
7. [Baseline et gisement, données supposées connues](#7-baseline-et-gisement-données-supposées-connues)
8. [Synthèse des perspectives](#8-synthèse-des-perspectives)

___

## 1. Cadre réglementaire du NEBCO et décomposition du problème

Le mécanisme NEBCO (Notification d'Échanges de Blocs de Consommation) permet à des Opérateurs d'Effacement (OE) agréés par RTE de valoriser des effacements de consommation sur les marchés de l'énergie — la veille pour le lendemain et en infrajournalier. Il succède au mécanisme NEBEF en vigueur depuis 2014 et s'en distingue principalement par la possibilité de valoriser également les modulations à la hausse dans le cadre de décalages de consommation (reports ou anticipations de consommation).

Concrètement, le fonctionnement est le suivant : l'Opérateur d'Effacement (OE) contractualise des clients capables de réduire ponctuellement leur consommation (industriels, gestionnaires de chauffe-eau, opérateurs de recharge de VE, etc.). Il construit des offres d'effacement qu'il soumet sur les marchés de l'énergie ou sur le mécanisme d'ajustement de RTE — la réduction de soutirage étant traitée, du point de vue du réseau, comme équivalente à une injection de puissance. Lorsqu'une offre est retenue, RTE notifie à l'OE un programme d'effacement — un profil de puissance à livrer sur un horizon donné. Ce volume est valorisé sur les marchés de l'énergie (bourse EPEX Spot ou gré-à-gré). L'OE doit alors activer ses clients pour délivrer ce volume, tout en respectant les contraintes du cadre NEBCO (bilan énergétique, plafond de capacité, versement aux fournisseurs des sites effacés). Le contrôle du volume effectivement réalisé est assuré a posteriori par RTE sur la base de courbes de référence.

C'est le problème de **dispatch interne** — ventiler le programme retenu entre les clients du portefeuille — qui est l'objet du présent projet.

### Décomposition en niveaux de décision

L'activité d'un OE se décompose en niveaux emboîtés :

```
Niveau 0  │ Caractérisation portefeuille (baseline, gisement)   ── hors scope
Niveau 1  │ Offre sur le marché NEBCO                           ── hors scope
Niveau 2  │ Dispatch interne post-notification RTE              ── CE PROJET
Niveau 3  │ Pilotage temps réel des équipements                 ── hors scope
```

Chaque niveau prend en entrée les sorties du précédent. La chaîne boucle : le réalisé mesuré au Niveau 3 alimente le Niveau 0 (mise à jour des baselines et du gisement), qui conditionne les offres du Niveau 1. Un dispatch qui ne permet pas de livrer le volume retenu dégrade l'indicateur de fiabilité de l'OE [NEBCO, art. 5.E.1.3.2.2]. 

Dans le problème réel, les niveaux 1 et 2 sont couplés : le coût interne du dispatch conditionne le prix auquel l'OE peut soumettre ses offres — un OE qui sous-estime ses coûts s'expose à des dispatches déficitaires, un OE qui les surestime n'est pas retenu. Le modèle v1 rompt ce couplage par hypothèse : le programme retenu $E_t^{retenu}$ est fixé et doit être livré intégralement (C1 en égalité). Le Niveau 2 se réduit alors à un problème de minimisation de coût, indépendant des paramètres de marché — les conditions de cette simplification sont détaillées en section 3.

___

## 2. Périmètre modélisé

La hiérarchie NEBCO organise les acteurs ainsi :

```
Opérateur d'Effacement (OE)              ← personne morale agréée par RTE
  └── Périmètre d'Effacement (PE)        ← un seul PE par OE, non transférable
        ├── EDE 1  (Télérelevée ou Profilée)
        │     ├── Site de Soutirage 1.1
        │     └── Site de Soutirage 1.2
        ├── EDE 2  (Télérelevée ou Profilée)
        │     └── ...
```

Le prototype v1 considère **un OE gérant un PE contenant une seule EDE**, laquelle regroupe les N clients du portefeuille. C'est une simplification de modélisation, pas une position réglementaire.

**La typologie de l'EDE (Télérelevée ou Profilée) n'est pas distinguée.** Cette distinction est pourtant importante dans NEBCO : elle conditionne la méthode de contrôle du réalisé (mesure directe des courbes de charge pour les sites télérelevés, méthode des panels pour les sites profilés), et donc la façon dont la baseline (courbe de consommation de référence) et le rebond sont reconstruits. En ignorant cette distinction, le modèle traite tous les clients comme s'ils étaient télérelevés avec mesure directe.

La distinction Télérelevée/Profilée a des conséquences qui dépassent le Niveau 2 et touchent directement le Niveau 1 (offre sur le marché). En effet, le **barème de versement fournisseur**  est **différencié par typologie d'EDE** : un barème pour les sites télérelevés (puissance > 36 kVA) et un pour les sites profilés (puissance ≤ 36 kVA), avec des formules propres à chaque catégorie. Ces barèmes sont publiés par RTE et approuvés par la CRE [CRE-2025-275].

En conséquence, lorsque l'OE construit son offre au Niveau 1, il doit anticiper le versement fournisseur en fonction de la composition de ses EDE — une EDE Profilée résidentielle n'a pas le même barème qu'une EDE Télérelevée industrielle. Cette différenciation n'a aucun impact sur le Niveau 2 (le versement est constant par rapport aux variables de dispatch, cf. section 3), mais elle conditionne la marge nette que l'OE peut espérer, et donc le prix auquel il peut soumettre ses offres d'effacement.

Conséquences pour la modélisation réelle :

- **Multi-EDE** : un OE peut avoir plusieurs EDE (une par typologie, ou par zone géographique pour le télérelevé). Chacune a son propre bilan énergétique à vérifier. L'extension naturelle serait de répliquer une contrainte de bilan énergétique C3 par EDE et de partitionner la consigne RTE entre EDE — ce qui revient à résoudre N sous-problèmes de dispatch couplés par le plafond OE global (C2).
- **Périodes de bilan différentes** : les périodes de contrôle du bilan C3 sont typiquement différentes pour Télérelevé et Profilé (voir section 5). Un modèle multi-EDE devrait respecter des périodes distinctes par EDE.

Cette limite ouvre la voie à une extension multi-EDE et à un bilan sur période glissante, identifiées dans la section 8.

___
## 3. Modélisation et fonction objectif
Cette section présente d'abord la modélisation retenue, puis justifie les hypothèses simplificatrices qui y conduisent.

### 3.1 Synthèse de la modélisation

L'objectif est de minimiser le coût total de dispatch.
$$
\min \sum_{c,t} \left( C_c^{act} \cdot x_{c,t} \cdot \Delta t + f_{c,t} \cdot \delta_{c,t} \right)
$$


| Symbole | Description | Unité | Variable de décision |
|---------|-------------|-------| ---------------------|
| $x_{c,t}$ | Puissance effacée par le client c au pas t | MW | Oui |
| $\delta_{c,t}$| Activation du client c au pas t | {0, 1} | Oui |
| $C_c^{act}$ | Coût variable d'activation du client c | €/MWh | Non |
| $f_{c,t}$ | Coût fixe d'activation | € | Non |
| $\Delta t$ | Durée d'un pas de temps | h | Non |


La formulation de ce modèle utilise les contraintes suivantes, dont les choix seront discutés dans la suite de ce document :

| # | Contrainte | Formulation |
|---|-----------|-------------|
| C1 | Livraison de la consigne RTE | $\sum_c x_{c,t} \cdot \Delta t = E_t^{retenu}$ par pas |
| C2 | Plafond de puissance de l'OE | $\sum_c x_{c,t} \leq P^{max}_{OE}$ par pas |
| C3 | Bilan énergétique EDE | $\sum_{c,t} r_{c,t} \cdot x_{c,t} \leq \sum_{c,t} x_{c,t}$ |
| C4 | Plafond d'effacement par client $c$ & couplage effacement / activation | $x_{c,t} \leq ub_{c,t} \cdot \delta_{c,t}$ |
| C5 | Seuil minimal d'activation du client $c$| $x_{c,t} \geq e_{min,c,t} \cdot \delta_{c,t}$ |

Avec les variables suivantes :

| Symbole | Description | Unité |
|---|-----------|-------------|
| $E_t^{retenu}$ | Énergie de la consigne RTE au pas $t$ | MWh |
| $P_{OE}^{max}$ | Plafond de puissance de l'OE | MW |
| $p_{c,t}^{max}$ | Puissance maximale effaçable par le consommateur $c$ au pas $t$ | MW |
| $ub_{c,t}$ | Borne supérieure de l'effacement du consommateur $c$ au pas $t$ | MW |

La borne supérieure $ub_{c,t} = \min(p^{max}_{c,t},\; conso\_ref_{c,t})$ intègre à la fois la puissance maximale ($p^{max}_{c,t}$) que le client $c$ consent à effacer et la contrainte de baseline (on ne peut pas effacer plus qu'on ne consomme). Elle intervient dans C4 et dans la borne de la variable $x_{c,t}$.

En pratique, C2 est rarement active si on contraint la livraison stricte de la consigne RTE : RTE ne devrait pas notifier un programme retenu excédant le plafond de l'OE. Néamoins la contrainte est conservée comme garde-fou de cohérence et deviendrait structurante si l'on relâchait C1 en inégalité (sur-livraison possible mais pénalisée).


### 3.2 Profit complet de l'OE

Sur l'horizon d'un programme d'effacement retenu, le profit π de l'OE s'écrit :

$$
\pi = \underbrace{\sum_t \lambda_t \cdot E_t^{retenu}}_{\text{vente de l'effacement}}
\;-\; \underbrace{\sum_t B \cdot E_t^{eff}}_{\text{compensation fournisseurs}}
\;-\; \underbrace{\sum_{c,t} \left( C_c^{act} \cdot x_{c,t} \cdot \Delta t + f_{c,t} \cdot \delta_{c,t} \right)}_{\text{coût dispatch interne}}- \underbrace{\sum_t \mu_t \cdot (E_t^{eff}-E_t^{retenu})}_{\text{pénalités}}
$$
avec $E_t^{eff}=\Delta t \sum_c x_{c,t} $ l'énergie totale effacée par l'OE sur le pas de temps $t$. Le terme de pénalité englobe notamment le règlement du prix des écarts sur le volume manquant.

Les trois termes sont :

- **Revenu NEBCO** — l'OE a vendu le volume $E_t^{retenu}$ sur les marchés de l'énergie au prix spot $λ_t$. Ce terme est théoriquement fixé dès la clôture du Niveau 1 (offre retenue par RTE) si l'OE arrive à livrer entièrement l'effacement et à le valoriser entièrement.
- **Versement fournisseur** — l'OE reverse aux fournisseurs des sites effacés une  compensation au barème forfaitaire $B$ fixé par la CRE (€/MWh), proportionnelle au volume effacé.
- **Coût dispatch interne** — compensations versées aux clients et coûts fixes d'activation, pilotables par l'OE via ses décisions $x_{c,t}$ et $δ_{c,t}$.
- **Pénalités** — modélise le coût des écarts sur le marché de l’électricité (mécanisme de déséquilibre). Bien que NEBCO n’impose pas de pénalité directe pour un écart de livraison, ce coût est réel et doit être pris en compte pour refléter la réalité économique de l’OE.

### 3.3 Équivalence sous C1 en égalité

La contrainte C1 impose la livraison exacte :

$$
E_t^{eff} =\sum_c x_{c,t} \cdot \Delta t = E_t^{retenu} \qquad \forall t
$$

Sous cette contrainte en égalié, les deux premiers termes de π sont **entièrement déterminés** :

- $λ_t$ et $E_t^{retenu}$ sont des entrées figées par le Niveau 1 — aucune variable de décision du Niveau 2 ne les affecte.
- $B$ est un barème forfaitaire connu à l'avance. Le versement total $B · E_t^{retenu} · Δt$ ne dépend que du volume global par pas, pas de la répartition $x_{c,t}$ entre clients. Deux dispatches internes différents livrant le même $E_t^{retenu}$ paient exactement le même versement fournisseur.

Ces deux termes sont donc **constants vis-à-vis des variables de décision $x_{c,t}$ et $δ_{c,t}$**. Ils disparaissent par différentiation dans le problème d'optimisation :

$$
\arg\max_{x,\delta} \pi \;=\; \arg\min_{x,\delta} \sum_{c,t} \left( C_c^{act} \cdot x_{c,t} \cdot \Delta t + f_{c,t} \cdot \delta_{c,t} \right)
$$

Minimiser le coût de dispatch interne est **mathématiquement équivalent** à maximiser le profit complet, conditionnellement à la contrainte de livraison. Le problème se simplifie sans perte d'optimalité.

### 3.4 Conditions de validité

L'équivalence tient strictement sous trois conditions :

1. **C1 est une égalité.** Si on relâche C1 en inégalité (extension envisagée : sous-livraison autorisée avec pénalité), alors le volume livré $Σ_c x_{c,t} · Δt$ devient une variable de décision. Le revenu NEBCO et le versement fournisseur dépendent de cette variable et doivent réapparaître explicitement dans l'objectif, avec la pénalité de sous-livraison :

  $$
  \max \sum_t (\lambda_t - B) \cdot L_t \cdot \Delta t \;-\; \text{coût interne} \;-\; P \cdot s_t
  $$

  où $L_t = Σ_c x_{c,t}$ est le volume livré et $s_t = E_t^{retenu} - L_t$ le slack de sous-livraison pénalisé au taux $P$.

2. **Le barème $B$ est indépendant du client au sein d'une même EDE.** En réalité, les barèmes sont différenciés par typologie d'EDE (Télérelevée vs Profilée). Le modèle v1 ne considérant qu'une seule EDE, $B$ est uniforme et la simplification est correcte.

3. **Le plan d'effacement retenu $E_t^{retenu}$ est fixé.** Si on co-optimisait Niveau 1 et Niveau 2 (offre + dispatch simultanés), les trois termes seraient à nouveau variables.

### 3.5 Bénéfices pratiques

Ignorer les deux premiers termes permet :

- Une **fonction objectif plus simple** à lire et à déboguer.
- Une **interprétation directe** des résultats : le coût optimal est le coût cash à débourser par l'OE pour honorer sa consigne.
- **Aucune dépendance** aux paramètres de marché ($\lambda_t$, $B$) dans le code du Niveau 2.

Si l'on relâchait C1 en inégalité (sous-livraison autorisée avec pénalité), ces simplifications ne tiendraient plus et l'objectif devrait réintégrer les termes de revenu et de versement.

___

## 4. Pourquoi MILP plutôt que LP

Un programme linéaire (LP) résout un problème d'optimisation sur un domaine convexe (polyèdre défini par des contraintes linéaires) avec un objectif linéaire. Cette structure garantit que tout optimum local est global, et que la théorie de la dualité s'applique pleinement (dualité forte, conditions Karush-Kuhn-Tucker (KKT), interprétation économique des multiplicateurs). Dès qu'on introduit des variables entières, le domaine admissible n'est plus convexe — c'est un ensemble discret de points, pas un polyèdre — et ces propriétés ne sont plus valables.

Pour notre problème, un LP offrirait un avantage analytique puissant : la dualité forte garantit l'existence de multiplicateurs de Lagrange interprétables comme **prix fictifs** des contraintes. On lirait directement la valeur marginale d'une unité supplémentaire de consigne (dual de C1), le coût économique du plafond réglementaire (dual de C2), ou la valeur d'une détente du bilan énergétique (dual de C3). C'est très utile pour l'analyse après résolution et la tarification interne entre OE et clients.

Or, plusieurs aspects du problème de dispatch sont intrinsèquement discrets :

- **Coût fixe d'activation** (télécom, usure, sollicitation client) : charge déclenchée dès lors qu'on active le client, indépendante du volume. Cela se modélise avec une variable binaire $\delta$ : $\delta = 1$ si le client est activé, $\delta = 0$ sinon. C'est cette variable qui permet de distinguer "le client n'est pas sollicité" ($x = 0$, $\delta = 0$) du cas "le client est sollicité à un certain niveau" ($x > 0$, $\delta = 1$).

- **Seuil minimal d'effacement si activé** : par exemple, un industriel ne peut pas répondre à un ordre de 50 kW alors qu'il a un process à 500 kW. La contrainte "x = 0 ou x ≥ e_min" est disjonctive, elle se formule naturellement avec $x ≥ e_min · δ$.
- **Contraintes inter-temporelles** (extension envisagée) : durée minimale d'effacement, temps de repos entre activations, nombre max d'activations — toutes entières par nature.

Tenter de modéliser ces aspects en LP pur revient à les relâcher (coûts fixes répartis au prorata, seuils ignorés) et à produire des dispatches physiquement irréalistes — un industriel activé à 10% de son seuil, par exemple.

La modélisation du problème en MILP fait perdre la dualité forte (les binaires cassent la convexité), mais garde la formulation fidèle au problème physique et contractuel. Le temps de calcul reste négligeable pour des portefeuilles de taille raisonnable : le prototype à 4 clients × 6 pas se résout en une fraction de seconde avec le solveur CBC (COIN-OR Branch and Cut), embarqué par défaut avec PuLP.

### Compromis pratique : relaxation LP à δ fixés

Une approche qui récupère une partie de l'analyse duale : résoudre le MILP complet pour trouver le plan d'activation optimal $δ*$, puis **résoudre la relaxation LP en fixant $δ = δ*$**. Les duaux obtenus sont interprétables **conditionnellement** à ce plan d'activation — ils répondent à la question "quelle serait la valeur marginale d'un MWh de consigne supplémentaire, *sans changer quels clients sont activés* ?" C'est une analyse de sensibilité locale, pas globale, mais elle est utile pour la tarification et la communication aux clients. Cette extension pourrait être implémentée dans une version ultérieure.

___

## 5. Modélisation du rebond

### 5.1 Définition du rebond NEBCO

Le rebond (ou *report de consommation*) désigne la consommation augmentée qui suit un effacement : un ballon d'eau chaude refroidi pendant un effacement consomme davantage ensuite pour se réchauffer ; un VE débranché pendant la pointe se rechargera plus tard. NEBCO reconnaît explicitement ce phénomène (art. L.271-1 du Code de l'énergie) et impose un bilan : l'énergie totale reportée (hausse) ne doit pas excéder l'énergie effacée (baisse), à la maille EDE.

### 5.2 Position actuelle : taux scalaire par pas (v1)

Le modèle v1 représente le rebond par un coefficient $r[c,t] ∈ [0, +∞[$ :

$$
\text{rebond}_{c,t} = r_{c,t} \cdot x_{c,t} \cdot \Delta t
$$

Ce coefficient capture l'**ampleur** du rebond mais pas son **timing**. Le rebond est supposé hors horizon d'optimisation — c'est-à-dire qu'il se produit après la fenêtre considérée par le modèle. C'est cohérent avec le fait qu'on utilise $r[c,t]$ uniquement dans C3 (bilan global), jamais dans C1 (livraison par pas).

Cette modélisation autorise $r > 1$ pour certains clients (chauffe-eau avec réchauffage moins efficace après coupure profonde, PAC avec grand écart thermique) pourvu que le bilan global à la maille EDE reste conforme.

**Limite principale** : en pratique, le rebond d'un effacement à 18h tombe à 19h-20h, donc *dans* l'horizon d'optimisation usuel. Ignorer ce timing fausse C1 sur les pas suivants : un effacement nominal de 1 MW à 18h peut être partiellement annulé par le rebond d'un effacement précédent.

### 5.3 Modélisation plus fidèle : matrice de réponse impulsionnelle

La modélisation fidèle remplace le scalaire par une **matrice de réponse impulsionnelle** $R_c[τ]$ : pour le client c, un effacement unitaire au pas $t$ génère un rebond $R_c[τ]$ au pas $t + τ$.

Le bilan de consommation au pas t devient :

$$
\text{conso\_réalisée}_{c,t} = \text{conso\_ref}_{c,t} \;-\; x_{c,t} \;+\; \sum_{\tau \geq 1} R_c[\tau] \cdot x_{c, t-\tau}
$$

Ce qui change :

- **C1 deviendrait dynamique** : la livraison nette à $t$ dépend des décisions aux pas antérieurs $t-τ$ via le rebond. Le problème reste linéaire (en $x$) mais devient couplé inter-temporellement.
- **C3 pourrait se simplifier** : si $Σ_τ R_c[τ] = r_c$ (intégrale du rebond = taux global), le bilan C3 s'obtient comme limite du cas scalaire ; mais la répartition temporelle est explicite.
- **Besoin d'identifier R_c** : mesure empirique à partir de données d'effacement passées, ou modèle physique pour les équipements simples (ballon d'eau chaude modélisé par une décharge exponentielle).

La matrice $R_c[τ]$ peut s'étendre aux valeurs τ < 0 pour modéliser les anticipations de consommation (hausse avant l'effacement), reconnues par NEBCO au même titre que les reports.

Cette extension serait le changement de modélisation le plus important, et celui qui rapprocherait le plus le modèle des contraintes opérationnelles réelles.

___

## 6. Bilan énergétique C3

La contrainte C3 du modèle v1 :

$$
\sum_{c,t} r_{c,t} \cdot x_{c,t} \cdot \Delta t \;\leq\; \sum_{c,t} x_{c,t} \cdot \Delta t
$$

est appliquée sur l'horizon d'optimisation court (6 pas demi-horaires = 3 heures dans l'exemple de référence).

NEBCO impose trois niveaux de contrôle de l'équilibre énergétique [CRE-2025-199]:

- **Validité des programmes déclarés** : les programmes soumis par l'OE   doivent être équilibrés (hausse ≤ baisse) sur **7 jours** pour les EDE Télérelevées et **2 jours** pour les EDE Profilées. Un programme déséquilibré est rejeté par RTE.
- **Bilan annuel réalisé** : RTE vérifie a posteriori, à la maille EDE, que les volumes réalisés de modulations à la hausse ne dépassent pas ceux à la baisse, sur l'année calendaire. Un bilan annuel non conforme entraîne la suspension de l'accord de participation (3 à 6 mois).
- **Suivi mensuel** : RTE calcule des bilans et ratios mensuels à titre de surveillance. En cas de non-conformité persistante, une limitation des volumes valorisables pourra être activée.

Le modèle v1 applique C3 sur l'horizon d'optimisation court (3 heures), ce qui est **significativement plus restrictif** que ces trois niveaux de contrôle. Une solution faisable au sens v1 est nécessairement faisable au sens NEBCO — le modèle sous-optimise peut-être, mais ne viole jamais la règle.


___

## 7. Baseline et gisement, données supposées connues

Deux entrées majeures du modèle sont supposées connues, alors qu'elles sont l'objet de sous-problèmes non triviaux :

### 7.1 Baseline (Courbe de Référence NEBCO)

$conso_ref[c,t]$ est la consommation qu'aurait eu le client en l'absence d'effacement. Elle sert à deux choses dans le modèle :
- Borne supérieure de l'effacement (on ne peut pas effacer plus qu'on ne
  consomme).
- Référence pour le contrôle du réalisé par RTE *a posteriori*.

La construction de la baseline est un problème statistique non trivial :
- Pour les sites Télérelevés, NEBCO propose plusieurs méthodes (rectangle à double référence corrigée, par prévision, par historique).
- Pour les sites Profilés, la méthode des panels introduite avec NEBCO compare la consommation des sites pilotés à un panel de sites représentatifs.

Le modèle v1 prend $conso_ref$ comme entrée. Un projet réel devrait soit intégrer un module de construction de baseline, soit coupler le dispatch à un service externe qui la fournit.

### 7.2 Gisement effaçable

$p^{max}_{c,t}$ est la puissance effaçable maximale, qui varie dans le temps selon :
- L'état physique de l'équipement (SOC d'un VE, niveau thermique d'un ballon, phase d'un process industriel).
- Les contraintes de confort ou de process du client.
- La disponibilité de la connexion télécom.

Le modèle v1 prend $p^{max}$ comme entrée déterministe. Extensions pertinentes :
- **Modèles physiques** par type d'équipement : équation thermique pour un ballon, modèle de recharge pour un VE, couplage avec le planning de production pour un industriel.
- **Incertitude stochastique** : $p^{max}$ connu seulement en distribution, résolution par *sample average approximation* (SAA) sur un ensemble de scénarios.

## 8. Synthèse des perspectives

Les choix documentés ici reflètent un arbitrage entre représentation fidèle du mécanisme NEBCO et facilité de mise en œuvre avec un MILP. Plusieurs directions d'amélioration se dégagent des limites discutées dans ce document :

- **Relâcher C1 en inégalité** : autoriser la sous-livraison moyennant une pénalité. L'objectif devrait alors réintégrer le revenu NEBCO et le versement fournisseur pour permettre l'arbitrage économique (cf. section 3.3).
- **Contraintes inter-temporelles** : durée minimale d'effacement, temps de repos entre activations, nombre maximal de sollicitations par client. Ces contraintes sont déterminantes pour les process industriels.
- **Rebond intra-horizon** : remplacer le taux scalaire par une matrice de réponse impulsionnelle $R_c[\tau]$, qui rendrait C1 dynamique et couplée inter-temporellement (cf. section 5.3).
- **Multi-EDE** : répliquer C3 par EDE et gérer des périodes de bilan distinctes selon la typologie Télérelevée/Profilée (cf. section 6).
- **Incertitude sur le gisement** : le $p^{max}_{c,t}$ réel n'est connu qu'en distribution — une approche stochastique (SAA sur scénarios) permettrait de robustifier le dispatch.



___

## Références

- Code de l'énergie, Livre II Titre VII, *L'effacement de consommation d'électricité* — articles [L.271-1](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000031067893) (définition de l'effacement, prise en compte du report de consommation), [L.271-2](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000051560254) (agrément technique de l'opérateur d'effacement, modalités de valorisation) et [L.271-3](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000043214830) (régime de versement vers les fournisseurs des sites effacés).
- Code de l'énergie, partie réglementaire — articles [R.271-1](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000033056210) (définition technique de l'effacement, modalités de prise en compte des  reports) et [R.271-2](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000033056218) (définition de l'opérateur d'effacement et objet de l'agrément technique).
- LOI n° 2015-992 du 17 août 2015 relative à la transition énergétique pour la croissance verte, art. 168 — création du régime de versement.
- LOI n° 2025-391 du 30 avril 2025, art. 17 — dernière modification de L.271-2 et L.271-3 (substitution du terme « opérateur d'effacement » par « agrégateur d'effacement » dans certaines dispositions).
- **[CRE-2025-199]** CRE, *Délibération n°2025-199 portant approbation des règles NEBCO*, juillet 2025.
- **[NEBCO]** RTE, *Règles de Marché — Chapitre 5 : NEBCO*, version en vigueur au 01/09/2025, en particulier art. 5.F (gestion du Périmètre d'Effacement).
- **[CRE-2025-275]** CRE, *Délibération n°2025-275 du 17 décembre 2025 portant approbation des dispositions générales des règles de marché de RTE* — barèmes forfaitaires de versement fournisseur pour les sites télérelevés et profilés en modèle régulé  ([Légifrance](https://www.legifrance.gouv.fr/jorf/id/JORFTEXT000053097596), [RTE — page des barèmes](https://www.services-rte.com/fr/decouvrez-nos-offres-de-services/baremes-versement-nebef.html)).
- J.C. Gilbert, *Optimisation Différentiable — Théorie et Algorithmes*, cours OPT-201/OPT-202, ENSTA Paris 2016-2017. [Page du cours](https://who.rocq.inria.fr/Jean-Charles.Gilbert/ensta/cours2a/optim.html)

